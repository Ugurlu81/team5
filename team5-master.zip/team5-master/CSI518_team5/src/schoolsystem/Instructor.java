package schoolsystem;

public class Instructor {

	private String instructor;
	//private String 
	
	public String getInstructor() {
		return instructor;
	}

	public void setInstructor(String instructor) {
		this.instructor = instructor;
	}

}
